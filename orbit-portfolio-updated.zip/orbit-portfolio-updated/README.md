# ORBIT — Group Portfolio Frontend

A responsive React portfolio for **Shambhavi, Sanika and Trisha**. Includes About, Projects, Team, Contact, a demo admin login, and a project manager dashboard.

## Requirements
- Node.js (LTS version)
- Visual Studio Code (recommended)

## Run the project

1. Extract `orbit-portfolio-frontend.zip`.
2. Open the extracted `portfolio_group_frontend` folder in VS Code.
3. In VS Code, select **Terminal → New Terminal**.
4. Run these commands in that terminal, one at a time:

```bash
npm install
npm run dev
```

5. Open the local URL shown in the terminal (usually `http://localhost:5173`).

To make a production build, run `npm run build`.

## Demo admin login
- **Username:** `admin`
- **Password:** `orbit2026`

Click **Admin login** in the top navigation. From the dashboard you can add, edit and delete projects. Changes are stored in your browser using `localStorage` and appear on the public Projects section.

## Contact form
The current frontend demo stores submitted contact messages in the browser's `localStorage` key `orbitContactSubmissions`. It does **not** send email or save to a shared database.

## Important security note
This is the frontend portion of a full-stack project. The demo login is deliberately simple and is **not secure authentication**: credentials are visible in the frontend source and can be bypassed. Do not deploy this login as a real admin gate. For the full-stack version, create an Express API, validate credentials on the server, hash passwords, issue a secure session/token, and store projects/contact submissions in a database. Admin permissions must be checked by the backend on every write request.

## Main files
- `src/App.jsx` — application state and page layout
- `src/data/projects.js` — starter projects
- `src/components/` — reusable React components
- `src/styles.css` — complete responsive styling


## Before submitting
- The project cards include example GitHub URL patterns using `your-username`. Replace them in `src/data/projects.js` with your real repository URLs. You can also edit the GitHub repository URL for each project in the admin dashboard.
- The interface uses text symbols/CSS instead of Lucide React, so `lucide-react` is not required.


import { useState } from "react";

export default function Contact() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(false);

  const update = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const submit = async (e) => {
    e.preventDefault();
    setStatus("");
    setLoading(true);

    try {
      const response = await fetch("http://localhost:5000/api/contacts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          subject: "Portfolio enquiry",
          message: form.message,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Failed to send your message.");
      }

      setStatus("Thanks! Your message has been sent successfully.");
      setForm({ name: "", email: "", message: "" });
    } catch (error) {
      console.error("Contact form error:", error);
      setStatus(
        "Unable to send your message. Please check that the backend is running and try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      className="section-wrap section-block contact-section"
      id="contact"
    >
      <div className="contact-panel">
        <div className="contact-copy">
          <span className="eyebrow">04 / START A CONVERSATION</span>
          <h2>
            Have a good
            <br />
            idea? <span className="gradient-text">Let’s talk.</span>
          </h2>
          <p>
            Have a project, question or collaboration in mind? Send us a note
            and let’s make something meaningful.
          </p>

          <div className="contact-detail">
            <span className="contact-symbol" aria-hidden="true">✉</span>
            <span>hello@orbit-studio.dev</span>
          </div>

          <div className="contact-detail">
            <span className="contact-symbol" aria-hidden="true">⌖</span>
            <span>India · Working everywhere</span>
          </div>
        </div>

        <form className="contact-form" onSubmit={submit}>
          <label>
            Your name
            <input
              name="name"
              value={form.name}
              onChange={update}
              placeholder="What should we call you?"
              required
            />
          </label>

          <label>
            Email address
            <input
              name="email"
              type="email"
              value={form.email}
              onChange={update}
              placeholder="you@example.com"
              required
            />
          </label>

          <label>
            Tell us a little about it
            <textarea
              name="message"
              value={form.message}
              onChange={update}
              placeholder="A few details about your idea..."
              rows="4"
              required
            />
          </label>

          <button
            className="button button-primary"
            type="submit"
            disabled={loading}
          >
            {loading ? "Sending..." : "Send message"}
            {!loading && <span aria-hidden="true"> ↗</span>}
          </button>

          {status && (
            <p className="form-status" role="status">
              {status}
            </p>
          )}
        </form>
      </div>
    </section>
  );
}

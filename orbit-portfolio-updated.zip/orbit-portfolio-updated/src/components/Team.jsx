
const members = [
  { n: "01", name: "Shambhavi", role: "Frontend & Experience", initials: "SH", color: "member-lilac", focus: "Turning ideas into clear, interactive interfaces." },
  { n: "02", name: "Sanika", role: "Design & Visual Systems", initials: "SA", color: "member-blue", focus: "Creating visual systems with consistency and character." },
  { n: "03", name: "Trisha", role: "Research & Development", initials: "TR", color: "member-peach", focus: "Exploring solutions and bringing concepts to life." }
];

export default function Team() {
  return <section className="section-wrap section-block team-section" id="team">
    <div className="section-heading"><div><span className="eyebrow">03 / THE PEOPLE</span><h2>Three perspectives.<br/><span className="muted">One shared ambition.</span></h2></div><p className="section-intro">Different strengths, shared curiosity. We bring our perspectives together to make better work.</p></div>
    <div className="team-grid">{members.map(m => <article className="member-card" key={m.name}><div className={`member-avatar ${m.color}`}><span>{m.initials}</span><small>{m.n}</small><div className="avatar-orbit"/></div><div className="member-details"><div><h3>{m.name}</h3><span>{m.role}</span></div></div><p>{m.focus}</p></article>)}</div>
  </section>;
}
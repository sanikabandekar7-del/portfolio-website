
export default function Hero() {
  return (
    <section className="hero section-wrap" id="home">
      <div className="hero-copy">
        <div className="eyebrow"><span className="status-dot"/> DIGITAL CRAFT • DEVELOPMENT • DESIGN</div>
        <h1>We turn bold<br/>ideas into <span className="gradient-text">digital</span><br/><span className="outline-text">experiences.</span></h1>
        <p className="hero-description">A collaborative portfolio exploring the space between thoughtful design and purposeful technology.</p>
        <div className="hero-actions">
          <a className="button button-primary" href="#projects">Explore our work <span aria-hidden="true">↗</span></a>
          <a className="text-link" href="#about">Get to know us <span aria-hidden="true">↓</span></a>
        </div>
        <div className="hero-meta"><span><b>03</b> collaborators</span><i/><span><b>∞</b> ideas in progress</span></div>
      </div>
      <div className="hero-art" aria-label="Abstract digital orbit illustration">
        <div className="art-grid"/>
        <div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit orbit-three"/>
        <div className="core"><div className="core-inner"><span className="code-symbol" aria-hidden="true">&lt;/&gt;</span><span>BUILD / CREATE</span></div></div>
        <div className="float-card card-top"><span aria-hidden="true">✦</span><span>Ideas into impact</span></div>
        <div className="float-card card-bottom"><span className="mini-bars"><i/><i/><i/><i/></span><span>Creative mode <b>ON</b></span></div>
        <span className="art-index">FIG. 001 / ORBIT SYSTEM</span>
      </div>
      <a className="scroll-cue" href="#about"><span className="scroll-line"/> SCROLL TO EXPLORE</a>
    </section>
  );
}
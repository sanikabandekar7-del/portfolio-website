
import { useState } from "react";

const API_URL = "http://localhost:5000/api";

const blank = {
  title: "",
  category: "Web Application",
  year: "2026",
  description: "",
  tagsText: "",
  link: "",
  githubLink: "",
  accent: "violet"
};

function formatProject(project, index = 0) {
  return {
    ...project,
    category: project.category || "Web Application",
    year: project.year || "2026",
    accent: project.accent || "violet",
    tags: typeof project.technologies === "string"
      ? project.technologies.split(",").map(tag => tag.trim()).filter(Boolean)
      : (project.tags || []),
    link: project.liveLink || project.link || "",
    number: String(index + 1).padStart(2, "0")
  };
}

export default function AdminDashboard({
  projects,
  setProjects,
  onClose,
  onLogout
}) {
  const [editing, setEditing] = useState(null);
  const [draft, setDraft] = useState(blank);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const startNew = () => {
    setDraft({ ...blank });
    setEditing("new");
    setNotice("");
    setError("");
  };

  const startEdit = project => {
    setDraft({
      ...blank,
      ...project,
      tagsText: (project.tags || []).join(", "),
      link: project.link || project.liveLink || ""
    });
    setEditing(project.id);
    setNotice("");
    setError("");
  };

  const update = event => {
    setDraft({
      ...draft,
      [event.target.name]: event.target.value
    });
  };

  async function save(event) {
    event.preventDefault();
    setSaving(true);
    setNotice("");
    setError("");

    const payload = {
      title: draft.title.trim(),
      description: draft.description.trim(),
      technologies: draft.tagsText
        .split(",")
        .map(tag => tag.trim())
        .filter(Boolean)
        .join(", "),
      githubLink: draft.githubLink.trim(),
      liveLink: draft.link.trim()
    };

    try {
      const isNew = editing === "new";
      const url = isNew
        ? `${API_URL}/projects`
        : `${API_URL}/projects/${editing}`;

      const response = await fetch(url, {
        method: isNew ? "POST" : "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Unable to save project.");
      }

      const savedProject = formatProject(result.project);

      if (isNew) {
        setProjects(previous => [
          savedProject,
          ...previous
        ]);
        setNotice("Project added to the database successfully.");
      } else {
        setProjects(previous =>
          previous.map(project =>
            String(project.id) === String(editing)
              ? savedProject
              : project
          )
        );
        setNotice("Project updated successfully.");
      }

      setEditing(null);
      setDraft({ ...blank });
    } catch (err) {
      setError(
        err.message === "Failed to fetch"
          ? "Cannot reach the backend. Make sure your Express server is running on port 5000."
          : err.message
      );
    } finally {
      setSaving(false);
    }
  }

  async function remove(id) {
    setNotice("");
    setError("");

    try {
      const response = await fetch(`${API_URL}/projects/${id}`, {
        method: "DELETE"
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Unable to delete project.");
      }

      setProjects(previous =>
        previous.filter(project => String(project.id) !== String(id))
      );

      setConfirmDelete(null);
      setNotice("Project deleted from the database.");
    } catch (err) {
      setError(
        err.message === "Failed to fetch"
          ? "Cannot reach the backend. Make sure your Express server is running."
          : err.message
      );
    }
  }

  return (
    <div className="admin-shell">
      <header className="admin-topbar">
        <a className="brand" href="#home" onClick={onClose}>
          <span className="brand-mark">O</span>
          <span>ORBIT<span className="brand-dot">.</span></span>
        </a>

        <div className="admin-top-label">
          <span className="status-dot" /> ADMIN WORKSPACE
        </div>

        <button className="admin-logout" onClick={onLogout}>
          <span aria-hidden="true">↪</span> Log out
        </button>
      </header>

      <main className="admin-main">
        <button
          className="back-link"
          onClick={() => {
            onClose();
            window.location.hash = "home";
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          <span aria-hidden="true">←</span> Back to homepage
        </button>

        <div className="admin-heading">
          <div>
            <span className="eyebrow">CONTROL CENTER / 01</span>
            <h1>Project <span className="gradient-text">manager.</span></h1>
            <p>Manage portfolio projects saved in your MySQL database.</p>
          </div>

          <button className="button button-primary" onClick={startNew}>
            <span aria-hidden="true">＋</span> Add project
          </button>
        </div>

        {notice && <p className="form-status" role="status">{notice}</p>}
        {error && <p className="form-status" role="alert">{error}</p>}

        <div className="admin-stats">
          <div>
            <span>Published projects</span>
            <b>{projects.length.toString().padStart(2, "0")}</b>
          </div>
          <div>
            <span>Workspace</span>
            <b>ORBIT / 01</b>
          </div>
          <div>
            <span>Storage</span>
            <b>MySQL database</b>
          </div>
        </div>

        {editing !== null && (
          <form className="project-editor" onSubmit={save}>
            <div className="editor-heading">
              <div>
                <span className="eyebrow">
                  {editing === "new" ? "NEW ENTRY" : "EDIT ENTRY"}
                </span>
                <h2>{editing === "new" ? "Add a project" : "Edit project details"}</h2>
              </div>

              <button
                type="button"
                className="icon-button"
                onClick={() => setEditing(null)}
                aria-label="Close editor"
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>

            <div className="editor-grid">
              <label>
                Project title
                <input
                  name="title"
                  value={draft.title}
                  onChange={update}
                  required
                  placeholder="e.g. Atlas Analytics"
                />
              </label>

              <label>
                Category
                <input
                  name="category"
                  value={draft.category}
                  onChange={update}
                  required
                  placeholder="Web Application"
                />
              </label>

              <label>
                Year
                <input
                  name="year"
                  value={draft.year}
                  onChange={update}
                  required
                  placeholder="2026"
                />
              </label>

              <label>
                Accent theme
                <select name="accent" value={draft.accent} onChange={update}>
                  <option value="violet">Violet</option>
                  <option value="cyan">Cyan</option>
                  <option value="orange">Orange</option>
                </select>
              </label>

              <label className="full-field">
                Description
                <textarea
                  name="description"
                  value={draft.description}
                  onChange={update}
                  rows="3"
                  required
                  placeholder="What did you build and why?"
                />
              </label>

              <label className="full-field">
                Tags <span className="field-hint">(comma separated)</span>
                <input
                  name="tagsText"
                  value={draft.tagsText}
                  onChange={update}
                  placeholder="React, UI/UX, Dashboard"
                />
              </label>

              <label className="full-field">
                Live project URL (optional)
                <input
                  name="link"
                  type="url"
                  value={draft.link}
                  onChange={update}
                  placeholder="https://your-live-project.com"
                />
              </label>

              <label className="full-field">
                GitHub repository URL (optional)
                <input
                  name="githubLink"
                  type="url"
                  value={draft.githubLink || ""}
                  onChange={update}
                  placeholder="https://github.com/username/repository"
                />
              </label>
            </div>

            <div className="editor-actions">
              <button
                type="button"
                className="button button-quiet"
                onClick={() => setEditing(null)}
                disabled={saving}
              >
                Cancel
              </button>

              <button
                className="button button-primary"
                type="submit"
                disabled={saving}
              >
                <span aria-hidden="true">✓</span>
                {saving ? "Saving..." : "Save project"}
              </button>
            </div>
          </form>
        )}

        <div className="admin-project-list">
          <div className="list-heading">
            <h2><span aria-hidden="true">▤</span> Your projects</h2>
            <span>{projects.length} total</span>
          </div>

          {projects.length === 0 && (
            <p className="admin-empty">
              No projects yet. Select “Add project” to publish one.
            </p>
          )}

          {projects.map(project => (
            <article className="admin-project-row" key={project.id}>
              <div className={`admin-project-icon ${project.accent || "violet"}`}>
                <span aria-hidden="true">▤</span>
              </div>

              <div className="admin-project-text">
                <h3>{project.title}</h3>
                <p>
                  {project.category || "Web Application"} · {project.year || "2026"}
                </p>
                <div className="tag-row">
                  {(project.tags || []).map(tag => (
                    <span className="tag" key={tag}>{tag}</span>
                  ))}
                </div>
              </div>

              <div className="admin-row-actions">
                <button
                  className="icon-button"
                  onClick={() => startEdit(project)}
                  aria-label={`Edit ${project.title}`}
                >
                  <span aria-hidden="true">✎</span>
                </button>

                <button
                  className="icon-button delete-button"
                  onClick={() => setConfirmDelete(project.id)}
                  aria-label={`Delete ${project.title}`}
                >
                  <span aria-hidden="true">⌫</span>
                </button>
              </div>

              {confirmDelete === project.id && (
                <div className="delete-confirm">
                  <span>Delete “{project.title}”?</span>
                  <button type="button" onClick={() => remove(project.id)}>
                    Delete
                  </button>
                  <button type="button" onClick={() => setConfirmDelete(null)}>
                    Keep
                  </button>
                </div>
              )}
            </article>
          ))}
        </div>

        <p className="admin-disclaimer">
          Project records are managed through the ORBIT API and stored in MySQL.
        </p>
      </main>
    </div>
  );
}


const capabilities = [
  { icon: <span aria-hidden="true">▧</span>, title: "Interface design", text: "Clean layouts, considered details and user-first experiences." },
  { icon: <span aria-hidden="true">&lt;/&gt;</span>, title: "Frontend development", text: "Responsive interfaces built with modern web technologies." },
  { icon: <span aria-hidden="true">⌖</span>, title: "Interaction thinking", text: "Small interactions that make digital products feel alive." }
];

export default function About() {
  return (
    <section className="section-wrap section-block" id="about">
      <div className="section-heading"><div><span className="eyebrow">01 / WHO WE ARE</span><h2>Curious minds.<br/><span className="muted">Carefully built things.</span></h2></div><p className="section-intro">We’re a team of learners and makers who believe good digital work should feel as good as it functions.</p></div>
      <div className="about-grid">
        <div className="about-note"><span className="quote-mark">“</span><p>Our process is equal parts curiosity, collaboration and iteration. We make things, learn from them, and make them better.</p><a href="#team" className="text-link">Meet the collaborators <span aria-hidden="true">↗</span></a></div>
        <div className="capability-list">{capabilities.map((item) => <article className="capability" key={item.title}><div className="cap-icon">{item.icon}</div><div><h3>{item.title}</h3><p>{item.text}</p></div></article>)}</div>
      </div>
    </section>
  );
}
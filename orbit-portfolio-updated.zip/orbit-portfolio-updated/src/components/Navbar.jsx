import { useEffect, useState } from "react";

const sections = ["home", "about", "projects", "team", "contact"];
const labels = { home: "Home", about: "About", projects: "Projects", team: "The team", contact: "Contact" };

export default function Navbar({ onLogin, isAdmin }) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("home");
  const close = () => setOpen(false);

  useEffect(() => {
    const updateActive = () => {
      const marker = window.scrollY + 150;
      let current = "home";
      for (const id of sections) {
        const section = document.getElementById(id);
        if (section && section.offsetTop <= marker) current = id;
      }
      setActive(current);
    };
    window.addEventListener("scroll", updateActive, { passive: true });
    window.addEventListener("hashchange", updateActive);
    updateActive();
    return () => {
      window.removeEventListener("scroll", updateActive);
      window.removeEventListener("hashchange", updateActive);
    };
  }, []);

  return (
    <header className="navbar">
      <a className="brand" href="#home" onClick={() => { close(); setActive("home"); }}><span className="brand-mark">O</span><span>ORBIT<span className="brand-dot">.</span></span></a>
      <button className="mobile-toggle" onClick={() => setOpen(!open)} aria-label="Toggle navigation">{open ? "×" : "☰"}</button>
      <nav className={open ? "nav-links open" : "nav-links"}>
        {sections.map(id => <a key={id} href={`#${id}`} className={active === id ? "active" : ""} aria-current={active === id ? "location" : undefined} onClick={() => { close(); setActive(id); }}>{labels[id]}</a>)}
        <button className="nav-login" onClick={() => { close(); onLogin(); }}>{isAdmin ? "Admin dashboard" : "Admin login"} <span aria-hidden="true">↗</span></button>
      </nav>
    </header>
  );
}

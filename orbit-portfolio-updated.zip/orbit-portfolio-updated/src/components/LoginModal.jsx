import { useState } from "react";

export default function LoginModal({ onClose, onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const submit = e => {
    e.preventDefault();
    if (username.trim() === "admin" && password === "orbit2026") {
      onLogin();
    } else {
      setError("Those demo credentials don't match. Check the details below.");
    }
  };
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><section className="login-modal" role="dialog" aria-modal="true" aria-labelledby="login-title"><button className="modal-close" onClick={onClose} aria-label="Close login"><span aria-hidden="true">×</span></button><div className="login-icon"><span className="lock-symbol" aria-hidden="true">▣</span></div><span className="eyebrow">RESTRICTED ACCESS</span><h2 id="login-title">Welcome back.</h2><p className="login-subtitle">Sign in to manage the ORBIT project portfolio.</p><form onSubmit={submit}><label>Username<input value={username} onChange={e => setUsername(e.target.value)} placeholder="Enter admin username" autoComplete="username" required /></label><label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter password" autoComplete="current-password" required /></label>{error && <p className="error-message">{error}</p>}<button className="button button-primary login-submit" type="submit">Sign in <span aria-hidden="true">↗</span></button></form><div className="demo-credentials"><b>DEMO ACCESS</b><span>Username: <code>admin</code></span><span>Password: <code>orbit2026</code></span></div><p className="security-note">Frontend demonstration only. Use server-side authentication before deploying.</p></section></div>;
}
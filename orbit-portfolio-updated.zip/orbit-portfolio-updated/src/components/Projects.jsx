
export default function Projects({ projects }) {
  return (
    <section className="section-wrap section-block projects-section" id="projects">
      <div className="section-heading"><div><span className="eyebrow">02 / SELECTED WORK</span><h2>Ideas made <span className="gradient-text">tangible.</span></h2></div><p className="section-intro">A selection of concepts and builds. Each project is a chance to explore a problem from a fresh angle.</p></div>
      <div className="project-list">
        {projects.map((project, index) => <article className={`project-card ${project.accent || "violet"}`} key={project.id}>
          <div className="project-visual"><div className="visual-grid"/><span className="project-number">{project.number || String(index + 1).padStart(2, "0")}</span><div className="visual-window"><div className="window-bar"><i/><i/><i/><span>{project.title}</span></div><div className="window-content"><div className="window-side"><b/><b/><b/><b/></div><div className="window-main"><span className="window-kicker">PROJECT / {project.year || "2026"}</span><strong>{project.title}</strong><div className="window-graph"><i/><i/><i/><i/><i/><i/><i/><i/></div><div className="window-lines"><i/><i/><i/></div></div></div></div><span className="visual-caption">DIGITAL OBJECT / {project.number || index + 1}</span></div>
          <div className="project-info"><div className="project-topline"><span>{project.category}</span><span>{project.year || "2026"}</span></div><h3>{project.title}</h3><p>{project.description}</p><div className="tag-row">{(project.tags || []).map(tag => <span className="tag" key={tag}>{tag}</span>)}</div><a className="project-link" href={project.githubLink || project.link || "#contact"} target={(project.githubLink || project.link || "").startsWith("http") ? "_blank" : undefined} rel="noreferrer">Explore project <span aria-hidden="true">↗</span></a></div>
        </article>)}
      </div>
      {projects.length === 0 && <div className="empty-projects">No projects published yet. Sign in to the admin dashboard to add your first project.</div>}
    </section>
  );
}
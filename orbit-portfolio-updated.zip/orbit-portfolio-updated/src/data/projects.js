// Replace each githubLink with the real GitHub repository URL before presenting the portfolio.
export const starterProjects = [
  {
    id: "p1",
    title: "Melody — Music Website",
    category: "Music Website",
    year: "2026",
    description: "A music-focused website experience designed to make discovering artists, tracks and playlists feel intuitive and engaging.",
    tags: ["HTML", "CSS", "JavaScript", "Responsive UI"],
    number: "01",
    accent: "violet",
    link: "",
    githubLink: "https://github.com/sanikabandekar7-del/music-app"
  },
  {
    id: "p2",
    title: "BURN — Gym Management System",
    category: "Gym Management System",
    year: "2026",
    description: "A gym management experience for presenting membership plans, fitness services and useful information through a clear interface.",
    tags: ["HTML", "CSS", "JavaScript", "Management UI"],
    number: "02",
    accent: "cyan",
    link: "",
    githubLink: "https://github.com/sanikabandekar7-del/gym-website"
  },
  {
    id: "p3",
    title: "Petal & Gold — Jewellery Store",
    category: "E-commerce Website",
    year: "2026",
    description: "A polished jewellery storefront concept that showcases collections and supports an easy product-browsing experience.",
    tags: ["E-commerce", "Product UI", "Responsive Design"],
    number: "03",
    accent: "orange",
    link: "",
    githubLink: "https://github.com/sanikabandekar7-del/4-Cards-gallery"
  }
];

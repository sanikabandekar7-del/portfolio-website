
import { useEffect, useState } from "react";
import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import About from "./components/About.jsx";
import Projects from "./components/Projects.jsx";
import Team from "./components/Team.jsx";
import Contact from "./components/Contact.jsx";
import LoginModal from "./components/LoginModal.jsx";
import AdminDashboard from "./components/AdminDashboard.jsx";
import { starterProjects } from "./data/projects.js";

const API_URL = "http://localhost:5000/api";

export default function App() {
  const [projects, setProjects] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("orbitProjects")) || starterProjects;
    } catch {
      return starterProjects;
    }
  });

  const [loadingProjects, setLoadingProjects] = useState(true);
  const [projectError, setProjectError] = useState("");

  const [showLogin, setShowLogin] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function loadProjects() {
      try {
        const response = await fetch(`${API_URL}/projects`);

        if (!response.ok) {
          throw new Error("Unable to load projects from the server.");
        }

        const data = await response.json();

        if (!Array.isArray(data)) {
          throw new Error("The server returned an invalid project list.");
        }

        const formattedProjects = data.map((project, index) => ({
          ...project,
          id: project.id,
          number: project.number || String(index + 1).padStart(2, "0"),
          category: project.category || "Development",
          year: project.year || "2026",
          tags:
            project.tags ||
            (typeof project.technologies === "string"
              ? project.technologies.split(",").map((tag) => tag.trim()).filter(Boolean)
              : []),
          githubLink: project.githubLink || "",
          link: project.liveLink || "",
        }));

        if (!cancelled) {
          setProjects(formattedProjects);
          setProjectError("");
        }
      } catch (error) {
        console.error("Project loading error:", error);

        if (!cancelled) {
          setProjectError(
            "Unable to load projects from the database. Please check that the backend is running."
          );
        }
      } finally {
        if (!cancelled) {
          setLoadingProjects(false);
        }
      }
    }

    loadProjects();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    localStorage.setItem("orbitProjects", JSON.stringify(projects));
  }, [projects]);

  const login = () => {
    setShowLogin(false);
    setIsAdmin(true);
    setShowAdmin(true);
  };

  const logout = () => {
    setIsAdmin(false);
    setShowAdmin(false);
  };

  if (showAdmin && isAdmin) {
    return (
      <AdminDashboard
        projects={projects}
        setProjects={setProjects}
        onClose={() => setShowAdmin(false)}
        onLogout={logout}
      />
    );
  }

  return (
    <>
      <div className="site-shell">
        <Navbar
          onLogin={() => (isAdmin ? setShowAdmin(true) : setShowLogin(true))}
          isAdmin={isAdmin}
        />

        <main>
          <Hero />
          <About />

          {loadingProjects && (
            <section className="section-wrap section-block">
              <p role="status">Loading projects...</p>
            </section>
          )}

          {!loadingProjects && projectError && (
            <section className="section-wrap section-block">
              <p role="alert">{projectError}</p>
              <button
                className="button button-primary"
                onClick={() => window.location.reload()}
              >
                Try again
              </button>
            </section>
          )}

          {!loadingProjects && !projectError && (
            <Projects projects={projects} />
          )}

          <Team />
          <Contact />
        </main>

        <footer className="footer section-wrap">
          <a className="brand" href="#home">
            <span className="brand-mark">O</span>
            <span>
              ORBIT<span className="brand-dot">.</span>
            </span>
          </a>

          <p>Built with curiosity by Shambhavi, Sanika &amp; Trisha.</p>

          <div className="footer-links">
            <a href="#home" aria-label="Back to top">
              ↑
            </a>
          </div>

          <span className="footer-copy">© 2026 ORBIT STUDIO</span>
        </footer>
      </div>

      {showLogin && (
        <LoginModal
          onClose={() => setShowLogin(false)}
          onLogin={login}
        />
      )}

      {isAdmin && !showAdmin && (
        <button
          className="admin-fab"
          onClick={() => setShowAdmin(true)}
        >
          Open admin dashboard <span aria-hidden="true">↗</span>
        </button>
      )}
    </>
  );
}


const { Sequelize } = require("sequelize");
const config = require("./config/config.json").development;

const sequelize = new Sequelize(
  config.database,
  config.username,
  config.password,
  {
    host: config.host,
    dialect: config.dialect,
    logging: false,
  }
);

async function testConnection() {
  try {
    await sequelize.authenticate();
    console.log("MySQL connection successful!");
    console.log("Connected to:", config.database);
  } catch (error) {
    console.error("Unable to connect to MySQL:");
    console.error(error.message);
    process.exitCode = 1;
  }
}

testConnection();

module.exports = sequelize;


const express = require("express");
const cors = require("cors");
const db = require("./models");

const app = express();
const PORT = 5000;
const { Project, Contact } = db;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({ message: "ORBIT Portfolio API is running" });
});

app.get("/api/health", async (req, res) => {
  try {
    await db.sequelize.authenticate();
    res.json({ status: "success", database: "connected" });
  } catch (error) {
    res.status(500).json({
      status: "error",
      message: "Database connection failed"
    });
  }
});

// Get all projects
app.get("/api/projects", async (req, res) => {
  try {
    const projects = await Project.findAll({
      order: [["createdAt", "DESC"]]
    });
    res.json(projects);
  } catch (error) {
    console.error("Fetch projects:", error.message);
    res.status(500).json({ message: "Unable to fetch projects" });
  }
});

// Add a project
app.post("/api/projects", async (req, res) => {
  try {
    const { title, description, technologies, githubLink, liveLink } = req.body;

    if (!title?.trim() || !description?.trim()) {
      return res.status(400).json({
        message: "Title and description are required"
      });
    }

    const project = await Project.create({
      title: title.trim(),
      description: description.trim(),
      technologies: technologies || "",
      githubLink: githubLink || "",
      liveLink: liveLink || ""
    });

    res.status(201).json({
      message: "Project created successfully",
      project
    });
  } catch (error) {
    console.error("Create project:", error.message);
    res.status(500).json({ message: "Unable to create project" });
  }
});

// Edit a project
app.put("/api/projects/:id", async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id);

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const { title, description, technologies, githubLink, liveLink } = req.body;

    if (!title?.trim() || !description?.trim()) {
      return res.status(400).json({
        message: "Title and description are required"
      });
    }

    await project.update({
      title: title.trim(),
      description: description.trim(),
      technologies: technologies || "",
      githubLink: githubLink || "",
      liveLink: liveLink || ""
    });

    res.json({
      message: "Project updated successfully",
      project
    });
  } catch (error) {
    console.error("Update project:", error.message);
    res.status(500).json({ message: "Unable to update project" });
  }
});

// Delete a project
app.delete("/api/projects/:id", async (req, res) => {
  try {
    const project = await Project.findByPk(req.params.id);

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    await project.destroy();
    res.json({ message: "Project deleted successfully" });
  } catch (error) {
    console.error("Delete project:", error.message);
    res.status(500).json({ message: "Unable to delete project" });
  }
});

// Save contact form submissions
app.post("/api/contacts", async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;

    if (!name?.trim() || !email?.trim() || !message?.trim()) {
      return res.status(400).json({
        message: "Name, email and message are required"
      });
    }

    const contact = await Contact.create({
      name: name.trim(),
      email: email.trim(),
      subject: subject || "",
      message: message.trim()
    });

    res.status(201).json({
      message: "Your message has been submitted successfully",
      contact
    });
  } catch (error) {
    console.error("Contact submission:", error.message);
    res.status(500).json({ message: "Unable to submit your message" });
  }
});

async function startServer() {
  try {
    await db.sequelize.authenticate();
    console.log("MySQL connection successful!");
    app.listen(PORT, () => {
      console.log(`ORBIT API running at http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("Unable to connect to MySQL:", error.message);
    process.exitCode = 1;
  }
}

startServer();
